# TaskPad – React To-Do List

Run locally:  npm install && npm run dev
Build:        npm run build   (output in /dist)
