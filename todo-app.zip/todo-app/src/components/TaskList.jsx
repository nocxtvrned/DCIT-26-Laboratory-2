import TaskItem from "./TaskItem.jsx";

export default function TaskList({ tasks, onToggle, onDelete, onClearDone, onReset }) {
  if (tasks.length === 0) {
    return (
      <p className="rounded-lg border border-dashed border-slate-300 p-6 text-center text-slate-500">
        No tasks yet. Type one above and press Add Task.
      </p>
    );
  }

  return (
    <>
      <ul className="space-y-3">
        {tasks.map((task) => (
          <TaskItem key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
        ))}
      </ul>
      <div className="mt-6 flex flex-wrap gap-2">
        <button
          onClick={onClearDone}
          disabled={!tasks.some((t) => t.done)}
          className="rounded-md border border-slate-300 px-3 py-1.5 text-sm font-medium hover:bg-slate-100 disabled:opacity-40"
        >
          Clear Done
        </button>
        <button
          onClick={onReset}
          className="rounded-md border border-red-300 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50"
        >
          Reset All
        </button>
      </div>
    </>
  );
}
