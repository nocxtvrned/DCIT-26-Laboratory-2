export default function Header({ tasks }) {
  const done = tasks.filter((t) => t.done).length;
  return (
    <header className="mb-6">
      <h1 className="text-3xl font-bold text-slate-900">TaskPad</h1>
      <p className="mt-1 text-slate-600">
        {tasks.length === 0
          ? "Nothing planned yet."
          : `${done} of ${tasks.length} tasks done`}
      </p>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-200">
        <div
          className="h-full bg-emerald-500 transition-all"
          style={{ width: tasks.length ? `${(done / tasks.length) * 100}%` : 0 }}
        />
      </div>
    </header>
  );
}
