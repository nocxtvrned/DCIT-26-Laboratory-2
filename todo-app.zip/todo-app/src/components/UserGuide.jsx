const steps = [
  {
    title: "How to add a task",
    body: "Type your task in the text box, then click Add Task (or press Enter).",
  },
  {
    title: "How to mark a task as Done or Not Done",
    body: "Click Mark Done on a task. Its label changes to Done and the text is crossed out. Click Mark Not Done to undo it.",
  },
  {
    title: "How to delete a task",
    body: "Click the red Delete button next to a task. Use Clear Done to remove all finished tasks, or Reset All to start over.",
  },
];

export default function UserGuide() {
  return (
    <aside className="h-fit rounded-2xl bg-white p-5 shadow sm:p-8">
      <h2 className="mb-4 text-xl font-bold text-slate-900">User Guide</h2>
      <div className="space-y-4">
        {steps.map((s) => (
          <section key={s.title}>
            <h3 className="font-semibold text-indigo-700">{s.title}</h3>
            <p className="mt-1 text-sm text-slate-600">{s.body}</p>
          </section>
        ))}
      </div>
    </aside>
  );
}
