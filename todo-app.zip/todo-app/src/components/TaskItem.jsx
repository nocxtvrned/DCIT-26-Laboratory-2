export default function TaskItem({ task, onToggle, onDelete }) {
  return (
    <li className="flex flex-col gap-3 rounded-lg border border-slate-200 p-3 sm:flex-row sm:items-center">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <span
          className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold ${
            task.done
              ? "bg-emerald-100 text-emerald-700"
              : "bg-amber-100 text-amber-700"
          }`}
        >
          {task.done ? "Done" : "Not Done"}
        </span>
        <span
          className={`break-words ${
            task.done ? "text-slate-400 line-through" : "text-slate-800"
          }`}
        >
          {task.text}
        </span>
      </div>
      <div className="flex gap-2">
        <button
          onClick={() => onToggle(task.id)}
          className="flex-1 rounded-md border border-slate-300 px-3 py-1.5 text-sm font-medium hover:bg-slate-100 sm:flex-none"
        >
          {task.done ? "Mark Not Done" : "Mark Done"}
        </button>
        <button
          onClick={() => onDelete(task.id)}
          className="flex-1 rounded-md bg-red-50 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-100 sm:flex-none"
        >
          Delete
        </button>
      </div>
    </li>
  );
}
