import { useState } from "react";
import Header from "./components/Header.jsx";
import TaskForm from "./components/TaskForm.jsx";
import TaskList from "./components/TaskList.jsx";
import UserGuide from "./components/UserGuide.jsx";

export default function App() {
  // React state: the list of tasks
  const [tasks, setTasks] = useState([
    { id: 1, text: "Try marking this task as Done", done: false },
  ]);

  // Feature 1: add a task dynamically
  const addTask = (text) => {
    setTasks((prev) => [...prev, { id: Date.now(), text, done: false }]);
  };

  // Feature 2: toggle Done / Not Done
  const toggleTask = (id) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );
  };

  // Feature 3: delete a task
  const deleteTask = (id) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  // Feature 4: clear completed / reset all
  const clearDone = () => setTasks((prev) => prev.filter((t) => !t.done));
  const resetAll = () => setTasks([]);

  return (
    <div className="min-h-screen bg-slate-100 px-4 py-8 sm:py-12">
      <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-[3fr_2fr]">
        <main className="rounded-2xl bg-white p-5 shadow sm:p-8">
          <Header tasks={tasks} />
          <TaskForm onAdd={addTask} />
          <TaskList
            tasks={tasks}
            onToggle={toggleTask}
            onDelete={deleteTask}
            onClearDone={clearDone}
            onReset={resetAll}
          />
        </main>
        <UserGuide />
      </div>
      <footer className="mt-8 text-center text-sm text-slate-500">
        Built with React and Tailwind CSS
      </footer>
    </div>
  );
}
